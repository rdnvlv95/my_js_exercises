function repainting(input) {

    let nylon = Number(input[0])  //1.	Необходимо количество найлон (в кв.м.) - цяло число в интервала [1... 100].
    let paint = Number(input[1]) //2.	Необходимо количество боя (в литри) - цяло число в интервала [1…100]
    let thinner = Number(input[2])  //3.	Количество разредител (в литри) - цяло число в интервала [1…30]
    let hoursForLabor = Number(input[3]) //4.	Часовете, за които майсторите ще свършат работата - цяло число в интервала [1…9]

    let nylonPrice = 1.50 //Предпазен найлон - 1.50 лв. за кв. метър
    let paintPrice = 14.50 //Боя - 14.50 лв. за литър
    let thinnerPrice = 5.00//Разредител за боя - 5.00 лв. за литър
    let bagsPrice = 0.40
    
    // още 10% от количеството боя и 2 кв.м. найло.
    paint = paint + paint * 0.10
    nylon = nylon + 2  

    let totalNylonPrice = nylon * nylonPrice
    let totalPaintPrice = paint * paintPrice
    let totalThinnerPrice = thinner * thinnerPrice

    let materialsSum = totalNylonPrice + totalPaintPrice + totalThinnerPrice + bagsPrice

    //Сумата, която се заплаща на майсторите за 1 час работа, е равна на 30% от сбора на всички разходи за материали.
 let laborPrice = (materialsSum * 0.3) * hoursForLabor
 console.log(materialsSum + laborPrice)

}

repainting(["10 ","11 ","4 ","8"])
    