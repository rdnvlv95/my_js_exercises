function depositSum (input) { 

    let depositedSum = Number(input[0]) //1.	Депозирана сума – реално число в интервала [100.00 … 10000.00]
    let depositDueDate = Number(input[1]) //2.	Срок на депозита (в месеци) – цяло число в интервала [1…12]
    let annualInterestRate = Number(input[2]) / 100 //3.	Годишен лихвен процент – реално число в интервала [0.00 …100.00] 

    let result = depositedSum + depositDueDate * ((depositedSum * annualInterestRate) / 12) //сума = депозирана сума  + срок на депозита * ((депозирана сума * годишен лихвен процент ) / 12)
    
    console.log(result)

}

depositSum(["2350","6 ","7"])