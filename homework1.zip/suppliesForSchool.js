function suppliesForSchool(input) {

        let pens = Number(input[0]) //Брой пакети химикали - цяло число в интервала [0...100]
        let markers = Number(input[1]) //Брой пакети маркери - цяло число в интервала [0...100]
        let cleaningSolution= Number(input[2]) //Литри препарат за почистване на дъска - цяло число в интервала [0…50]

        let discount = Number(input[3]) / 100 //Процент намаление - цяло число в интервала [0...100]


        let sum = (pens * 5.80) + (markers * 7.20) + (cleaningSolution * 1.20)
        let discountedSum = sum - (sum * discount)

        console.log(discountedSum)

}

suppliesForSchool (["2 ","3 ", "4 ","25 "])
    