function fishTank (input) {

let length = Number(input[0]) //1.	Дължина в см – цяло число в интервала [10 … 500]
let width = Number(input[1]) //2.	Широчина в см – цяло число в интервала [10 … 300]
let height = Number(input[2]) //3.	Височина в см – цяло число в интервала [10… 200]
let percentageForItems = Number(input[3]) / 100 //4.	Процент  – реално число в интервала [0.000 … 100.000]

let volumeDecilitres = length * width * height //Един литър вода се равнява на един кубичен дециметър/ 1л=1 дм3/. 
let volumeLitres = volumeDecilitres * 0.001
let neededLitres = volumeLitres - volumeLitres * percentageForItems

console.log(neededLitres)

//литрите вода, които ще събира аквариума

}

fishTank(["85","75","47","17"])