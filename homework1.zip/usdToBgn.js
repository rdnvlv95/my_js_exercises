function usdToBgn(input) { //фиксиран курс между долар и лев: 1 USD = 1.79549 BGN
    let usd = Number(input[0])
    let bgn = usd * 1.79549
    console.log(bgn)

}
usdToBgn(["22"])