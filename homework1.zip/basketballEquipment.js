function basketballEquipment (input) {

let basketFeeForAyear = Number(input[0])

let basketShoesPrice =   basketFeeForAyear - (basketFeeForAyear * 0.4)
let basketClothesPrice = basketShoesPrice - (basketShoesPrice * 0.2)
let basketBallPrice = basketClothesPrice / 4
let basketAccessoriesPrice = basketBallPrice / 5

let sum = basketFeeForAyear + basketShoesPrice + basketClothesPrice + basketBallPrice + basketAccessoriesPrice

console.log(sum)
}

basketballEquipment(["365"])