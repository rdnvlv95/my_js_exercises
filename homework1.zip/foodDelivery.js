function foodDelivery(input) {

   
let chickenMenus = Number(input[0]) //Брой пилешки менюта – цяло число в интервала [0 … 99]
let fishMenus = Number(input[1]) //Брой менюта с риба – цяло число в интервала [0 … 99]
let vegetarianMenus = Number(input[2]) //Брой вегетариански менюта – цяло число в интервала [0 … 99]

// цени 

let chickenPrice = 10.35
let fishPrice = 12.40 
let vegetarianPrice =  8.15 
let deliveryPrice = 2.50

//Групата ще си поръча и десерт, чиято цена е равна на 20% от общата сметка (без доставката). 

let sumMenus= (chickenMenus * chickenPrice) + (fishMenus * fishPrice) + (vegetarianMenus * vegetarianPrice)

let dessertPrice = sumMenus * 0.2

console.log(sumMenus + dessertPrice + deliveryPrice)

}

foodDelivery(["2 ","4 ","3"])